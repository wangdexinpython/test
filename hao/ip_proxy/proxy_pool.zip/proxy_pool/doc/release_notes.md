## Release Notes

* 1.13 (2019.02)

  1.使用.py文件替换.ini作为配置文件；
  
  2.更新代理采集部分；
  
* 1.12 (2018.4)

  1.优化代理格式检查;

  2.增加代理源;

  3.fix bug [#122](https://github.com/jhao104/proxy_pool/issues/122) [#126](https://github.com/jhao104/proxy_pool/issues/126)

* 1.11 (2017.8)

　　1.使用多线程验证useful_pool;

* 1.10 (2016.11)

　　1. 第一版；

　　2. 支持PY2/PY3;

　　3. 代理池基本功能；